# AnyKernel3 Ramdisk Mod Script
# osm0sis @ xda-developers

## AnyKernel setup
# begin properties
properties() { '
kernel.string=KnightWalker-シズカ-Shizuka
kernel.compiler=TheRagingBeast
kernel.made=Ryuuji @ItsRyuujiX
kernel.version=4.19.282
message.word=When you think positive, good things happen.
build.date=2023-05-16
build.type=RELEASE
do.devicecheck=1
do.modules=0
do.systemless=1
do.cleanup=1
do.cleanuponabort=0
device.name1=X00TD
device.name2=X00T
device.name3=Zenfone Max Pro M1 (X00TD)
device.name4=ASUS_X00TD
device.name5=ASUS_X00T
supported.versions=11-13
supported.patchlevels=
'; } # end properties

# Installation Method
X00TD=1

# shell variables
if [ "$X00TD" = "1" ];then
block=/dev/block/platform/soc/c0c4000.sdhci/by-name/boot;
else
block=/dev/block/bootdevice/by-name/boot;
fi
is_slot_device=0;
ramdisk_compression=auto;
patch_vbmeta_flag=auto;


## AnyKernel methods (DO NOT CHANGE)
# import patching functions/variables - see for reference
. tools/ak3-core.sh;

# Mount partitions as rw
mount /system;
mount /vendor;
mount -o remount,rw /system;
mount -o remount,rw /vendor;

## AnyKernel file attributes
# set permissions/ownership for included ramdisk files
if [ "$X00TD" = "1" ];then
chmod -R 750 $ramdisk/*;
chmod -R 755 $ramdisk/sbin;
chmod -R root:root $ramdisk/*;
else
set_perm_recursive 0 0 755 644 $ramdisk/*;
set_perm_recursive 0 0 755 755 $ramdisk/init* $ramdisk/sbin;
fi


## AnyKernel install
dump_boot;

# Check if boot img has Magisk Patched
cd $split_img;
if [ ! "$magisk_patched" ]; then
  $bin/magiskboot cpio ramdisk.cpio test;
  magisk_patched=$?;
fi;
if [ $((magisk_patched & 3)) -eq 1 ]; then
	if [ "$REG" = "IDN" ];then
	ui_print "! Magisk Terdeteksi, Tidak Perlu Menginstall Magisk lagi !";
	elif [ "$REG" = "JAV" ];then
	ui_print "! Magisk Dideteksi, Ora perlu nginstall Magisk maneh !";
	elif [ "$REG" = "SUN" ];then
	ui_print "! Magisk Dideteksi, Henteu kedah masang Magisk deui !";
	elif [ "$REG" = "EN" ];then
	ui_print "! Magisk Detected, U don't need to reinstall Magisk !";
	fi;
	WITHMAGISK=Y
fi;
cd $home

# begin ramdisk changes

#Remove old kernel stuffs from ramdisk
if [ "$X00TD" = "1" ];then
 rm -rf $ramdisk/init.special_power.sh
 rm -rf $ramdisk/init.darkonah.rc
 rm -rf $ramdisk/init.spectrum.rc
 rm -rf $ramdisk/init.spectrum.sh
 rm -rf $ramdisk/init.boost.rc
 rm -rf $ramdisk/init.trb.rc
 rm -rf $ramdisk/init.azure.rc
 rm -rf $ramdisk/init.PBH.rc
 rm -rf $ramdisk/init.Pbh.rc
 rm -rf $ramdisk/init.overdose.rc
fi

backup_file init.rc;
if [ "$X00TD" = "1" ];then
remove_line init.rc "import /init.darkonah.rc";
remove_line init.rc "import /init.spectrum.rc";
remove_line init.rc "import /init.boost.rc";
remove_line init.rc "import /init.trb.rc"
remove_line init.rc "import /init.azure.rc"
remove_line init.rc "import /init.PbH.rc"
remove_line init.rc "import /init.Pbh.rc"
remove_line init.rc "import /init.overdose.rc"
else
replace_string init.rc "cpuctl cpu,timer_slack" "mount cgroup none /dev/cpuctl cpu" "mount cgroup none /dev/cpuctl cpu,timer_slack";

# init.tuna.rc
backup_file init.tuna.rc;
insert_line init.tuna.rc "nodiratime barrier=0" after "mount_all /fstab.tuna" "\tmount ext4 /dev/block/platform/omap/omap_hsmmc.0/by-name/userdata /data remount nosuid nodev noatime nodiratime barrier=0";
append_file init.tuna.rc "bootscript" init.tuna;

# fstab.tuna
backup_file fstab.tuna;
patch_fstab fstab.tuna /system ext4 options "noatime,barrier=1" "noatime,nodiratime,barrier=0";
patch_fstab fstab.tuna /cache ext4 options "barrier=1" "barrier=0,nomblk_io_submit";
patch_fstab fstab.tuna /data ext4 options "data=ordered" "nomblk_io_submit,data=writeback";
append_file fstab.tuna "usbdisk" fstab;

# remove spectrum profile
	if [ -e $ramdisk/init.spectrum.rc ];then
	  rm -rf $ramdisk/init.spectrum.rc
	  ui_print "delete /init.spectrum.rc"
	fi
	if [ -e $ramdisk/init.spectrum.sh ];then
	  rm -rf $ramdisk/init.spectrum.sh
	  ui_print "delete /init.spectrum.sh"
	fi
	if [ -e $ramdisk/sbin/init.spectrum.rc ];then
	  rm -rf $ramdisk/sbin/init.spectrum.rc
	  ui_print "delete /sbin/init.spectrum.rc"
	fi
	if [ -e $ramdisk/sbin/init.spectrum.sh ];then
	  rm -rf $ramdisk/sbin/init.spectrum.sh
	  ui_print "delete /sbin/init.spectrum.sh"
	fi
	if [ -e $ramdisk/etc/init.spectrum.rc ];then
	  rm -rf $ramdisk/etc/init.spectrum.rc
	  ui_print "delete /etc/init.spectrum.rc"
	fi
	if [ -e $ramdisk/etc/init.spectrum.sh ];then
	  rm -rf $ramdisk/etc/init.spectrum.sh
	  ui_print "delete /etc/init.spectrum.sh"
	fi
	if [ -e $ramdisk/init.aurora.rc ];then
	  rm -rf $ramdisk/init.aurora.rc
	  ui_print "delete /init.aurora.rc"
	fi
	if [ -e $ramdisk/sbin/init.aurora.rc ];then
	  rm -rf $ramdisk/sbin/init.aurora.rc
	  ui_print "delete /sbin/init.aurora.rc"
	fi
	if [ -e $ramdisk/etc/init.aurora.rc ];then
	  rm -rf $ramdisk/etc/init.aurora.rc
	  ui_print "delete /etc/init.aurora.rc"
	fi
fi

# rearm perfboostsconfig.xml
if [ ! -f /vendor/etc/perf/perfboostsconfig.xml ]; then
	mv /vendor/etc/perf/perfboostsconfig.xml.bak /vendor/etc/perf/perfboostsconfig.xml;
	mv /vendor/etc/perf/perfboostsconfig.xml.bkp /vendor/etc/perf/perfboostsconfig.xml;
fi

# rearm commonresourceconfigs.xml
if [ ! -f /vendor/etc/perf/commonresourceconfigs.xml ]; then
	mv /vendor/etc/perf/commonresourceconfigs.xml.bak /vendor/etc/perf/commonresourceconfigs.xml;
	mv /vendor/etc/perf/commonresourceconfigs.xml.bkp /vendor/etc/perf/commonresourceconfigs.xml;
fi

# rearm targetconfig.xml
if [ ! -f /vendor/etc/perf/targetconfig.xml ]; then
	mv /vendor/etc/perf/targetconfig.xml.bak /vendor/etc/perf/targetconfig.xml;
	mv /vendor/etc/perf/targetconfig.xml.bkp /vendor/etc/perf/targetconfig.xml;
fi

# rearm targetresourceconfigs.xml
if [ ! -f /vendor/etc/perf/targetresourceconfigs.xml ]; then
	mv /vendor/etc/perf/targetresourceconfigs.xml.bak /vendor/etc/perf/targetresourceconfigs.xml;
	mv /vendor/etc/perf/targetresourceconfigs.xml.bkp /vendor/etc/perf/targetresourceconfigs.xml;
fi

# rearm powerhint.xml
if [ ! -f /vendor/etc/powerhint.xml ]; then
	mv /vendor/etc/powerhint.xml.bak /vendor/etc/powerhint.xml;
	mv /vendor/etc/powerhint.xml.bkp /vendor/etc/powerhint.xml;
fi

# CPU & GPU Freq Selection
if [ "`$BB grep "OVERCLOCK=" "$config" | $BB cut -c11`" == Y ];then
OVERCLOCKED="CPU & GPU"
patch_cmdline overclock.cpu overclock.cpu=1
patch_cmdline overclock.gpu overclock.gpu=1
elif [ "`$BB grep "OVERCLOCK=" "$config" | $BB cut -c11`" == C ];then
OVERCLOCKED="CPU"
patch_cmdline overclock.cpu overclock.cpu=1
patch_cmdline overclock.gpu overclock.gpu=0
elif [ "`$BB grep "OVERCLOCK=" "$config" | $BB cut -c11`" == G ];then
OVERCLOCKED="GPU"
patch_cmdline overclock.cpu overclock.cpu=0
patch_cmdline overclock.gpu overclock.gpu=1
else
OVERCLOCKED=""
patch_cmdline overclock.cpu overclock.cpu=0
patch_cmdline overclock.gpu overclock.gpu=0
fi

if [ ! -z "OVERCLOCKED" ];then
if [ "$REG" = "IDN" ] || [ "$REG" = "SUN" ] || [ "$REG" = "JAV" ];then
ui_print "- $OVERCLOCKED di-Overclock !";
elif [ "$REG" = "EN" ];then
ui_print "- $OVERCLOCKED is Overclocked !";
fi;
else
if [ "$REG" = "IDN" ] || [ "$REG" = "SUN" ] || [ "$REG" = "JAV" ];then
ui_print "- CPU & GPU masih di Freq Stock !";
elif [ "$REG" = "EN" ];then
ui_print "- CPU & GPU is still at Stock Freq !";
fi;
fi

# NVT Driver Selection
if [ "`$BB grep "NVTDRIVER=" "$config" | $BB cut -c11-13`" == NTC ];then
if [ "$REG" = "IDN" ] || [ "$REG" = "SUN" ] || [ "$REG" = "JAV" ];then
ui_print "- NTC Dipilih, Menggunakan Driver NVT Baru ...";
elif [ "$REG" = "EN" ];then
ui_print "- NTC Selected, Using New NVT Driver ...";
fi;
patch_cmdline use_new_nvtouch use_new_nvtouch=1
else
if [ "$REG" = "IDN" ] || [ "$REG" = "SUN" ] || [ "$REG" = "JAV" ];then
ui_print "- OTC Dipilih, Menggunakan Driver NVT Original ...";
elif [ "$REG" = "EN" ];then
ui_print "- OTC Selected, Using Original NVT Driver ...";
fi;
patch_cmdline use_new_nvtouch use_new_nvtouch=0
fi

# Switch SELinux
if [ "`$BB grep "SELINUX=" "$config" | $BB cut -c9`" == P ] || [ "`$BB grep "SELINUX=" "$config" | $BB cut -c9`" == E ];then
if [ "`$BB grep "SELINUX=" "$config" | $BB cut -c9`" == E ];then
SELINUXSTATE="Enforcing"
patch_cmdline androidboot.selinux androidboot.selinux=enforcing
elif [ "`$BB grep "SELINUX=" "$config" | $BB cut -c9`" == P ];then
SELINUXSTATE="Permissive"
patch_cmdline androidboot.selinux androidboot.selinux=permissive
fi

if [ "$REG" = "IDN" ];then
ui_print "- SELinux diganti ke: $SELINUXSTATE";
elif [ "$REG" = "JAV" ];then
ui_print "- SELinux diganti dadi: $SELINUXSTATE";
elif [ "$REG" = "SUN" ];then
ui_print "- SELinux digantikeun ka: $SELINUXSTATE";
elif [ "$REG" = "EN" ];then
ui_print "- SELinux switched to: $SELINUXSTATE";
fi;
fi;

# Refresh Rate
RR="$($BB grep "REFRESHRATE=" "$config" | $BB cut -c13-14)"

if [ -z "$RR" ] || [ "$RR" -lt "48" ] || [ "$RR" -gt "72" ]; then
if [ "$REG" = "IDN" ];then
ui_print "- Refresh Rate pada config Tidak Valid, 60Hz diatur sebagai default ...";
elif [ "$REG" = "JAV" ];then
ui_print "- Refresh Rate ing konfig ora valid, 60Hz disetel minangka standar ...";
elif [ "$REG" = "SUN" ];then
ui_print "- Refresh Rate dina konfig teu valid, 60Hz disetel salaku standar ...";
elif [ "$REG" = "EN" ];then
ui_print "- Invalid Refresh Rate in config, 60Hz is set as default ...";
fi;
RR=60
fi;
ui_print "- Refresh Rate: $RR Hz.";

if [ "$RR" = "60" ]; then
if [ "$REG" = "IDN" ];then
ui_print "- Melompati Modifikasi Refresh Rate ...";
elif [ "$REG" = "JAV" ];then
ui_print "- Nglumpati Modifikasi Refresh Rate ...";
elif [ "$REG" = "SUN" ];then
ui_print "- Ngalangkungan Modifikasi Refresh Rate ...";
elif [ "$REG" = "EN" ];then
ui_print "- Skipping Modify Refresh Rate ...";
fi;
else
if [ "$REG" = "IDN" ] || [ "$REG" = "SUN" ] || [ "$REG" = "JAV" ];then
ui_print "- Memodifikasi Refresh Rate ...";
elif [ "$REG" = "EN" ];then
ui_print "- Modifying Refresh Rate ...";
fi;
fi;
patch_cmdline refresh.rate refresh.rate=$RR;

# KernelSU Support
if [ "`$BB grep "ENABLEKSU=" "$config" | $BB cut -c11`" == Y ] || [ "`$BB grep "ENABLEKSU=" "$config" | $BB cut -c11`" == S ] && [ -z "$WITHMAGISK" ];then

if [ "`$BB grep "ENABLEKSU=" "$config" | $BB cut -c11`" == S ];then
patch_cmdline kernelsu.safemode kernelsu.safemode=1
if [ "$REG" = "IDN" ] || [ "$REG" = "SUN" ] || [ "$REG" = "JAV" ];then
KSUSAFEMODE=" (Mode Aman)"
elif [ "$REG" = "EN" ];then
KSUSAFEMODE=" (Safe Mode)"
fi;
else
patch_cmdline kernelsu.safemode kernelsu.safemode=0
KSUSAFEMODE=""
fi;

if [ "$REG" = "IDN" ];then
ui_print "- KernelSU dihidupkan$KSUSAFEMODE !";
elif [ "$REG" = "JAV" ];then
ui_print "- KernelSU diuripke$KSUSAFEMODE !";
elif [ "$REG" = "SUN" ];then
ui_print "- KernelSU diaktifkeun$KSUSAFEMODE !";
elif [ "$REG" = "EN" ];then
ui_print "- KernelSU enabled$KSUSAFEMODE !";
fi;
patch_cmdline kernelsu.enabled kernelsu.enabled=1
else
if [ ! -z "$WITHMAGISK" ];then
if [ "$REG" = "IDN" ];then
ui_print "- KernelSU dimatikan karena Magisk Terinstall !";
elif [ "$REG" = "JAV" ];then
ui_print "- KernelSU dipateni amarga Magisk dipasang !";
elif [ "$REG" = "SUN" ];then
ui_print "- KernelSU dinon-aktifkeun disebabkeun Magisk dipasang !";
elif [ "$REG" = "EN" ];then
ui_print "- KernelSU disabled due Magisk is Installed !";
fi;
else
if [ "$REG" = "IDN" ];then
ui_print "- KernelSU dimatikan !";
elif [ "$REG" = "JAV" ];then
ui_print "- KernelSU dipateni !";
elif [ "$REG" = "SUN" ];then
ui_print "- KernelSU dinon-aktifkeun !";
elif [ "$REG" = "EN" ];then
ui_print "- KernelSU disabled !";
fi;
fi;
patch_cmdline kernelsu.enabled kernelsu.enabled=0
fi

# end ramdisk changes

write_boot;
## end install

